# Ablation study report

- Training pairs: 1868576
- Evaluation pairs (held-out test half): 198919
- Pair features in the full model: 76
- Baseline feature settings: `case=preserve|char=[3]x256|pos=[2]x128(heuristic)|fw=true|full=false|pair=ABSOLUTE|zclip=5.0`
- Seeds: [42] (single run, no variance estimate)
- Total run time: 1191.8 min

**Metric:** macro-F1 (the mean of the F1 of the *change* class and of the *no change* class, pooled over all boundaries - the measure PAN 2026 ranks by) on the held-out test half. The F1 of the change class alone is in `ablation_results.csv`. Thresholds (all three models) are chosen on the validation data by macro-F1, never on the evaluation data. Parameters and pipeline settings are ranked by **validation** macro-F1.

## 0. The difficulty levels

PAN 2026 scores **easy, medium and hard as three separate datasets** (the best systems use a separate recipe for each), so every table below reports the levels separately. The pairs of one level can be very different from another (medium has very few changes), so a threshold that is best for all pairs pooled is not best for any one level. Two numbers are therefore kept for every level: *pooled thr.* = the one threshold chosen on the pooled validation data (how the first version reported), and *own thr.* = the threshold chosen on that level's validation data only. The *own thr.* number is the one that corresponds to a submission for that dataset and is used in all per-level columns of this report. Run `-Ddifficulty=easy|medium|hard` to train and evaluate on one level only.

**Baselines on the evaluation pairs of each level** (macro-F1; the official test baselines are in `docs/RESEARCH.md`):

| Level | Pairs | Share of changes | Always "no change" | Always "change" |
|---|---:|---:|---:|---:|
| easy | 43426 | 29.7 % | 0.4129 | 0.2288 |
| medium | 106682 | 4.5 % | 0.4885 | 0.0430 |
| hard | 48811 | 21.1 % | 0.4409 | 0.1745 |

**The baseline setting of each model, per level** (evaluation macro-F1):

| Model | Level | Pooled thr. | Own thr. | Own threshold |
|---|---|---:|---:|---:|
| Decision Tree | easy | 0.9203 | 0.9378 | 0.4975 |
| Decision Tree | medium | 0.5038 | 0.5021 | 0.7250 |
| Decision Tree | hard | 0.4465 | 0.5459 | 0.4375 |
| Logistic Regression | easy | 0.9138 | 0.9353 | 0.0500 |
| Logistic Regression | medium | 0.5073 | 0.5073 | 0.1900 |
| Logistic Regression | hard | 0.4492 | 0.5389 | 0.0050 |
| Neural Network | easy | 0.9217 | 0.9468 | 0.5200 |
| Neural Network | medium | 0.5063 | 0.5062 | 0.7350 |
| Neural Network | hard | 0.4442 | 0.5407 | 0.3750 |

## 1. Feature-group ablation

`Importance(G) = MacroF1_all - MacroF1_without_G`. Positive = the group carries useful information. Near 0 = it adds nothing the other groups do not already provide. Negative = the model does better without it. "Only G" trains on that group alone. The per-difficulty columns are the same difference on easy / medium / hard pairs, each level with the threshold chosen on that level's own validation data (PAN scores every level as its own dataset).

## 3. Feature-pipeline ablation

The features are computed again for every setting (casing, character n-gram order and buckets, POS n-grams, pair representation, ...) and the models are trained with the baseline hyperparameters. Every cell is `validation / test` macro-F1; `◀` = the baseline setting, `★` = best validation macro-F1 of that model within the family.

### Casing of the text (preserve / lower-case / hybrid)

| Setting | Pair features | Decision Tree | Logistic Regression | Neural Network |
|---|---:|---:|---:|---:|
| preserve ◀ | 76 | 0.7177 / 0.7114 | 0.7162 / 0.7100 | 0.7188 / 0.7130 |
| lowercase | 76 | 0.7179 / 0.7110 | 0.7157 / 0.7095 | 0.7180 / 0.7124 |
| hybrid | 76 | 0.7180 / 0.7110 ★ | 0.7163 / 0.7092 ★ | 0.7190 / 0.7126 ★ |

### Character n-gram order n

| Setting | Pair features | Decision Tree | Logistic Regression | Neural Network |
|---|---:|---:|---:|---:|
| n=1 | 76 | 0.7137 / 0.7070 | 0.7152 / 0.7088 | 0.7186 / 0.7123 |
| n=2 | 76 | 0.7177 / 0.7105 ★ | 0.7170 / 0.7097 ★ | 0.7190 / 0.7121 |
| n=3 ◀ | 76 | 0.7177 / 0.7114 | 0.7162 / 0.7100 | 0.7188 / 0.7130 |
| n=4 | 76 | 0.7176 / 0.7105 | 0.7155 / 0.7092 | 0.7197 / 0.7126 ★ |
| n=5 | 76 | 0.7159 / 0.7099 | 0.7152 / 0.7080 | 0.7192 / 0.7127 |
| none | 72 | 0.7135 / 0.7060 | 0.7122 / 0.7061 | 0.7189 / 0.7119 |

### Hash buckets of the character profile

| Setting | Pair features | Decision Tree | Logistic Regression | Neural Network |
|---|---:|---:|---:|---:|
| buckets=16 | 76 | 0.7135 / 0.7062 | 0.7130 / 0.7063 | 0.7182 / 0.7121 |
| buckets=32 | 76 | 0.7136 / 0.7063 | 0.7134 / 0.7065 | 0.7194 / 0.7124 |
| buckets=64 | 76 | 0.7145 / 0.7074 | 0.7141 / 0.7072 | 0.7186 / 0.7125 |
| buckets=128 | 76 | 0.7166 / 0.7098 | 0.7147 / 0.7084 | 0.7188 / 0.7128 |
| buckets=256 ◀ | 76 | 0.7177 / 0.7114 | 0.7162 / 0.7100 | 0.7188 / 0.7130 |
| buckets=512 | 76 | 0.7212 / 0.7152 | 0.7174 / 0.7107 | 0.7192 / 0.7131 |
| buckets=1024 | 76 | 0.7236 / 0.7148 | 0.7185 / 0.7114 | 0.7190 / 0.7118 |
| buckets=2048 | 76 | 0.7258 / 0.7169 ★ | 0.7189 / 0.7113 ★ | 0.7195 / 0.7126 ★ |

### Typed character n-grams (affix + punctuation)

| Setting | Pair features | Decision Tree | Logistic Regression | Neural Network |
|---|---:|---:|---:|---:|
| all n-grams ◀ | 76 | 0.7177 / 0.7114 | 0.7162 / 0.7100 ★ | 0.7188 / 0.7130 ★ |
| typed (affix+punct) | 76 | 0.7186 / 0.7124 ★ | 0.7161 / 0.7090 | 0.7185 / 0.7130 |

### POS n-gram order

| Setting | Pair features | Decision Tree | Logistic Regression | Neural Network |
|---|---:|---:|---:|---:|
| none | 72 | 0.7175 / 0.7113 | 0.7156 / 0.7094 | 0.7192 / 0.7124 ★ |
| n=1 | 76 | 0.7175 / 0.7113 | 0.7164 / 0.7100 ★ | 0.7184 / 0.7126 |
| n=2 ◀ | 76 | 0.7177 / 0.7114 ★ | 0.7162 / 0.7100 | 0.7188 / 0.7130 |
| n=3 | 76 | 0.7175 / 0.7113 | 0.7160 / 0.7098 | 0.7189 / 0.7130 |

### Hash buckets of the POS profile

| Setting | Pair features | Decision Tree | Logistic Regression | Neural Network |
|---|---:|---:|---:|---:|
| buckets=32 | 76 | 0.7175 / 0.7113 | 0.7163 / 0.7101 ★ | 0.7191 / 0.7133 |
| buckets=64 | 76 | 0.7175 / 0.7113 | 0.7162 / 0.7099 | 0.7190 / 0.7132 |
| buckets=128 ◀ | 76 | 0.7177 / 0.7114 ★ | 0.7162 / 0.7100 | 0.7188 / 0.7130 |
| buckets=256 | 76 | 0.7176 / 0.7114 | 0.7161 / 0.7093 | 0.7188 / 0.7132 |
| buckets=512 | 76 | 0.7176 / 0.7112 | 0.7160 / 0.7091 | 0.7196 / 0.7129 ★ |

### POS tagger

| Setting | Pair features | Decision Tree | Logistic Regression | Neural Network |
|---|---:|---:|---:|---:|
| heuristic ◀ | 76 | 0.7177 / 0.7114 ★ | 0.7162 / 0.7100 ★ | 0.7188 / 0.7130 ★ |

### Function-word profile

| Setting | Pair features | Decision Tree | Logistic Regression | Neural Network |
|---|---:|---:|---:|---:|
| off | 72 | 0.7177 / 0.7114 ★ | 0.7165 / 0.7091 ★ | 0.7184 / 0.7125 |
| on ◀ | 76 | 0.7177 / 0.7114 ★ | 0.7162 / 0.7100 | 0.7188 / 0.7130 ★ |

### Pair representation (how two sentences become one vector)

| Setting | Pair features | Decision Tree | Logistic Regression | Neural Network |
|---|---:|---:|---:|---:|
| absolute ◀ | 76 | 0.7177 / 0.7114 ★ | 0.7162 / 0.7100 | 0.7188 / 0.7130 |
| signed | 76 | 0.7151 / 0.7094 | 0.6488 / 0.6426 | 0.7139 / 0.7070 |
| mean | 76 | 0.6805 / 0.6742 | 0.6953 / 0.6885 | 0.7048 / 0.6969 |
| relative | 76 | 0.7170 / 0.7112 | 0.7252 / 0.7197 ★ | 0.7239 / 0.7196 ★ |

### Cut of the z-scores of the scalar features

| Setting | Pair features | Decision Tree | Logistic Regression | Neural Network |
|---|---:|---:|---:|---:|
| off | 76 | 0.7177 / 0.7114 | 0.7165 / 0.7090 | 0.7180 / 0.7116 |
| +-3 | 76 | 0.7188 / 0.7129 ★ | 0.7175 / 0.7108 ★ | 0.7221 / 0.7155 ★ |
| +-5 ◀ | 76 | 0.7177 / 0.7114 | 0.7162 / 0.7100 | 0.7188 / 0.7130 |
| +-10 | 76 | 0.7177 / 0.7114 | 0.7164 / 0.7095 | 0.7185 / 0.7111 |

### Compressed (4 measures per profile) vs full (every bucket difference)

| Setting | Pair features | Decision Tree | Logistic Regression | Neural Network |
|---|---:|---:|---:|---:|
| compressed (4 measures) ◀ | 76 | 0.7177 / 0.7114 ★ | 0.7162 / 0.7100 ★ | 0.7188 / 0.7130 ★ |

## 3b. Feature-pipeline ablation, by difficulty level

The same runs as section 3, but the evaluation macro-F1 of each level separately (threshold chosen on that level's validation data). Cell = easy / medium / hard.

### Casing of the text (preserve / lower-case / hybrid)

| Setting | Decision Tree | Logistic Regression | Neural Network |
|---|---:|---:|---:|
| preserve ◀ | 0.9378 / 0.5021 / 0.5459 | 0.9353 / 0.5073 / 0.5389 | 0.9468 / 0.5062 / 0.5407 |
| lowercase | 0.9382 / 0.5026 / 0.5456 | 0.9352 / 0.5055 / 0.5403 | 0.9445 / 0.5059 / 0.5456 |
| hybrid | 0.9382 / 0.5026 / 0.5456 | 0.9356 / 0.5064 / 0.5381 | 0.9463 / 0.5057 / 0.5410 |

### Character n-gram order n

| Setting | Decision Tree | Logistic Regression | Neural Network |
|---|---:|---:|---:|
| n=1 | 0.9330 / 0.5016 / 0.5452 | 0.9346 / 0.5063 / 0.5352 | 0.9458 / 0.5066 / 0.5428 |
| n=2 | 0.9399 / 0.5024 / 0.5488 | 0.9371 / 0.5083 / 0.5390 | 0.9461 / 0.5048 / 0.5259 |
| n=3 ◀ | 0.9378 / 0.5021 / 0.5459 | 0.9353 / 0.5073 / 0.5389 | 0.9468 / 0.5062 / 0.5407 |
| n=4 | 0.9353 / 0.5036 / 0.5429 | 0.9355 / 0.5064 / 0.5359 | 0.9460 / 0.5055 / 0.5467 |
| n=5 | 0.9339 / 0.5007 / 0.5445 | 0.9343 / 0.5060 / 0.5351 | 0.9452 / 0.5053 / 0.5475 |
| none | 0.9320 / 0.5007 / 0.5353 | 0.9290 / 0.5035 / 0.5277 | 0.9451 / 0.5046 / 0.5482 |

### Hash buckets of the character profile

| Setting | Decision Tree | Logistic Regression | Neural Network |
|---|---:|---:|---:|
| buckets=16 | 0.9324 / 0.5004 / 0.5354 | 0.9309 / 0.5045 / 0.5293 | 0.9457 / 0.5057 / 0.5433 |
| buckets=32 | 0.9324 / 0.5005 / 0.5354 | 0.9319 / 0.5040 / 0.5298 | 0.9450 / 0.5051 / 0.5478 |
| buckets=64 | 0.9333 / 0.5001 / 0.5356 | 0.9321 / 0.5042 / 0.5321 | 0.9464 / 0.5068 / 0.5432 |
| buckets=128 | 0.9346 / 0.4994 / 0.5417 | 0.9333 / 0.5041 / 0.5356 | 0.9467 / 0.5062 / 0.5415 |
| buckets=256 ◀ | 0.9378 / 0.5021 / 0.5459 | 0.9353 / 0.5073 / 0.5389 | 0.9468 / 0.5062 / 0.5407 |
| buckets=512 | 0.9432 / 0.5044 / 0.5538 | 0.9388 / 0.5076 / 0.5385 | 0.9466 / 0.5065 / 0.5427 |
| buckets=1024 | 0.9443 / 0.5064 / 0.5555 | 0.9409 / 0.5092 / 0.5391 | 0.9464 / 0.5039 / 0.5249 |
| buckets=2048 | 0.9467 / 0.5090 / 0.5619 | 0.9404 / 0.5088 / 0.5406 | 0.9458 / 0.5058 / 0.5511 |

### Typed character n-grams (affix + punctuation)

| Setting | Decision Tree | Logistic Regression | Neural Network |
|---|---:|---:|---:|
| all n-grams ◀ | 0.9378 / 0.5021 / 0.5459 | 0.9353 / 0.5073 / 0.5389 | 0.9468 / 0.5062 / 0.5407 |
| typed (affix+punct) | 0.9367 / 0.5033 / 0.5399 | 0.9343 / 0.5067 / 0.5382 | 0.9421 / 0.5071 / 0.5447 |

### POS n-gram order

| Setting | Decision Tree | Logistic Regression | Neural Network |
|---|---:|---:|---:|
| none | 0.9378 / 0.5020 / 0.5459 | 0.9350 / 0.5072 / 0.5371 | 0.9456 / 0.5056 / 0.5447 |
| n=1 | 0.9377 / 0.5020 / 0.5459 | 0.9365 / 0.5068 / 0.5355 | 0.9458 / 0.5056 / 0.5438 |
| n=2 ◀ | 0.9378 / 0.5021 / 0.5459 | 0.9353 / 0.5073 / 0.5389 | 0.9468 / 0.5062 / 0.5407 |
| n=3 | 0.9376 / 0.5020 / 0.5459 | 0.9357 / 0.5070 / 0.5376 | 0.9468 / 0.5052 / 0.5412 |

### Hash buckets of the POS profile

| Setting | Decision Tree | Logistic Regression | Neural Network |
|---|---:|---:|---:|
| buckets=32 | 0.9378 / 0.5020 / 0.5459 | 0.9361 / 0.5074 / 0.5372 | 0.9438 / 0.5068 / 0.5452 |
| buckets=64 | 0.9378 / 0.5020 / 0.5459 | 0.9351 / 0.5060 / 0.5386 | 0.9463 / 0.5064 / 0.5434 |
| buckets=128 ◀ | 0.9378 / 0.5021 / 0.5459 | 0.9353 / 0.5073 / 0.5389 | 0.9468 / 0.5062 / 0.5407 |
| buckets=256 | 0.9378 / 0.5021 / 0.5459 | 0.9353 / 0.5063 / 0.5390 | 0.9466 / 0.5058 / 0.5424 |
| buckets=512 | 0.9377 / 0.5021 / 0.5459 | 0.9354 / 0.5066 / 0.5393 | 0.9460 / 0.5059 / 0.5513 |

### POS tagger

| Setting | Decision Tree | Logistic Regression | Neural Network |
|---|---:|---:|---:|
| heuristic ◀ | 0.9378 / 0.5021 / 0.5459 | 0.9353 / 0.5073 / 0.5389 | 0.9468 / 0.5062 / 0.5407 |

### Function-word profile

| Setting | Decision Tree | Logistic Regression | Neural Network |
|---|---:|---:|---:|
| off | 0.9379 / 0.5021 / 0.5511 | 0.9383 / 0.5058 / 0.5383 | 0.9458 / 0.5063 / 0.5419 |
| on ◀ | 0.9378 / 0.5021 / 0.5459 | 0.9353 / 0.5073 / 0.5389 | 0.9468 / 0.5062 / 0.5407 |

### Pair representation (how two sentences become one vector)

| Setting | Decision Tree | Logistic Regression | Neural Network |
|---|---:|---:|---:|
| absolute ◀ | 0.9378 / 0.5021 / 0.5459 | 0.9353 / 0.5073 / 0.5389 | 0.9468 / 0.5062 / 0.5407 |
| signed | 0.9250 / 0.5031 / 0.5481 | 0.8537 / 0.5197 / 0.5473 | 0.9383 / 0.4986 / 0.4917 |
| mean | 0.8904 / 0.5152 / 0.5545 | 0.9162 / 0.5233 / 0.5679 | 0.9472 / 0.5237 / 0.5160 |
| relative | 0.9268 / 0.5073 / 0.5569 | 0.9492 / 0.5155 / 0.5498 | 0.9525 / 0.5100 / 0.5374 |

### Cut of the z-scores of the scalar features

| Setting | Decision Tree | Logistic Regression | Neural Network |
|---|---:|---:|---:|
| off | 0.9378 / 0.5022 / 0.5459 | 0.9367 / 0.5063 / 0.5362 | 0.9463 / 0.5069 / 0.5417 |
| +-3 | 0.9343 / 0.5033 / 0.5452 | 0.9355 / 0.5050 / 0.5395 | 0.9473 / 0.5051 / 0.5550 |
| +-5 ◀ | 0.9378 / 0.5021 / 0.5459 | 0.9353 / 0.5073 / 0.5389 | 0.9468 / 0.5062 / 0.5407 |
| +-10 | 0.9378 / 0.5022 / 0.5459 | 0.9356 / 0.5065 / 0.5372 | 0.9455 / 0.5041 / 0.5245 |

### Compressed (4 measures per profile) vs full (every bucket difference)

| Setting | Decision Tree | Logistic Regression | Neural Network |
|---|---:|---:|---:|
| compressed (4 measures) ◀ | 0.9378 / 0.5021 / 0.5459 | 0.9353 / 0.5073 / 0.5389 | 0.9468 / 0.5062 / 0.5407 |

## 4. How to read this (limitations to state in the paper)

- **Correlated groups.** If two groups carry the same information (e.g. sentence length and word length), removing one costs little because the other compensates, so a small importance does not prove a group is useless. The "only G" column helps tell the two cases apart.
- **One parameter at a time** ignores interactions between parameters (the decision-tree grid is the only place interactions are looked at).
- **Single run vs seeds.** Without several seeds there is no variance estimate; differences of a few thousandths of F1 should not be interpreted. Run with `-Dseeds=42,123,456` for the final numbers.
- **POS tags** come from the lightweight rule-based tagger (features.HeuristicPosTagger) unless `pos_tagger: corenlp` is in the pipeline table, so the POS result describes that tagger.
- **Pipeline settings are compared one at a time** around the baseline. The best value of each family is a candidate, not a proven combination (the optional `char_grid` family looks at n x buckets together).
- Parameters and pipeline settings are chosen on validation macro-F1; the test column is reported once, for the chosen values, and should not be used to pick settings.
